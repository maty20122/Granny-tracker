GRANNY TRACKER – projekt pro vytvoření APK

CO JE UVNITŘ
- main.py: aplikace v Kivy
- buildozer.spec: nastavení sestavení APK

DŮLEŽITÉ
Toto je zdrojový projekt, ne hotové APK. Pydroid 3 APK přímo nesestaví.
Sestavení proveď na počítači s Linuxem (např. Ubuntu) nebo v Linuxovém prostředí.

UBUNTU / LINUX – PŘÍKLAD
1. Nainstaluj systémové balíčky:
   sudo apt update
   sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv      build-essential autoconf libtool pkg-config zlib1g-dev libncurses-dev      libffi-dev libssl-dev

2. Ve složce projektu vytvoř virtuální prostředí a nainstaluj Buildozer:
   python3 -m venv .venv
   source .venv/bin/activate
   pip install --upgrade pip setuptools wheel
   pip install buildozer cython

3. V kořenové složce projektu spusť:
   buildozer -v android debug

4. Po úspěšném sestavení hledej APK ve složce:
   bin/

APK přenes do telefonu, otevři ho a povol instalaci z daného zdroje.
Pak aplikaci nainstaluj a její ikonu přidej na plochu.

POZNÁMKA
První sestavení stahuje Android SDK/NDK a může trvat delší dobu.
Při chybě sestavení pošli celý konec výpisu chyby.
