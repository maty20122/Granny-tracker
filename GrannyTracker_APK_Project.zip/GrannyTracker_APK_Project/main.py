from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
import json, os

CATEGORIES = ["Obtížnost", "Grafika", "Hratelnost", "Atmosféra", "Zvuk", "Celkové dojmy"]

KV = r"""
<DarkButton@Button>:
    background_normal: ''
    background_color: (0.15, 0.18, 0.24, 1)
    color: (0.92, 0.94, 0.98, 1)
    size_hint_y: None
    height: dp(44)
<Root>:
    orientation: 'vertical'
    padding: dp(12)
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: (0.035, 0.045, 0.07, 1)
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: '[b]GRANNY TRACKER[/b]\\n[color=8b9bb4]ULTIMATE HORROR GAME DATABASE[/color]'
        markup: True
        size_hint_y: None
        height: dp(68)
        font_size: '20sp'
        halign: 'center'
    BoxLayout:
        size_hint_y: None
        height: dp(46)
        spacing: dp(6)
        TextInput:
            id: search
            hint_text: 'Hledat hru...'
            multiline: False
            on_text: app.refresh()
        DarkButton:
            text: '+ PŘIDAT'
            size_hint_x: .38
            on_release: app.add_game()
    Label:
        id: stats
        text: '0 her'
        size_hint_y: None
        height: dp(24)
        color: (0.55, 0.66, 0.8, 1)
    ScrollView:
        do_scroll_x: False
        GridLayout:
            id: games
            cols: 1
            spacing: dp(8)
            padding: dp(2)
            size_hint_y: None
            height: self.minimum_height
"""

class Root(BoxLayout):
    pass

class GrannyTracker(App):
    title = "Granny Tracker"

    def build(self):
        self.data_path = os.path.join(self.user_data_dir, "games.json")
        self.games = self.load_data()
        Builder.load_string(KV)
        root = Root()
        self.root = root
        self.refresh()
        return root

    def load_data(self):
        try:
            with open(self.data_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def save_data(self):
        os.makedirs(self.user_data_dir, exist_ok=True)
        with open(self.data_path, "w", encoding="utf-8") as f:
            json.dump(self.games, f, ensure_ascii=False, indent=2)

    def add_game(self):
        box = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(12))
        name = TextInput(hint_text="Název hry", multiline=False, size_hint_y=None, height=dp(46))
        box.add_widget(name)
        actions = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        popup = Popup(title="Přidat hru", content=box, size_hint=(.88, None), height=dp(170))
        cancel = Button(text="Zrušit")
        add = Button(text="Přidat")
        actions.add_widget(cancel); actions.add_widget(add)
        box.add_widget(actions)
        cancel.bind(on_release=popup.dismiss)
        def commit(_):
            value = name.text.strip()
            if value and not any(g["name"].lower() == value.lower() for g in self.games):
                self.games.append({"name": value, "done": False, "ratings": {}, "expanded": True})
                self.save_data()
                self.refresh()
            popup.dismiss()
        add.bind(on_release=commit)
        popup.open()

    def rate(self, game, category, value):
        game["ratings"][category] = value
        self.save_data()
        self.refresh()

    def refresh(self, *_):
        if not self.root:
            return
        container = self.root.ids.games
        container.clear_widgets()
        term = self.root.ids.search.text.lower().strip()
        shown = [g for g in self.games if term in g["name"].lower()]
        self.root.ids.stats.text = f"{len(self.games)} her celkem • {len([g for g in self.games if g.get('done')])} dokončeno"
        for game in shown:
            card = BoxLayout(orientation="vertical", size_hint_y=None, padding=dp(10), spacing=dp(6))
            card.bind(minimum_height=card.setter("height"))
            top = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
            title = Label(text=f"[b]{game['name']}[/b]", markup=True, halign="left", valign="middle")
            title.bind(size=lambda inst, val: setattr(inst, "text_size", val))
            toggle = Button(text="SBALIT" if game.get("expanded", True) else "ROZBALIT", size_hint_x=.32)
            toggle.bind(on_release=lambda _, g=game: self.toggle(g))
            top.add_widget(title); top.add_widget(toggle)
            card.add_widget(top)
            if game.get("expanded", True):
                done = Button(text="✓ Dokončeno" if game.get("done") else "Označit jako dokončené",
                              size_hint_y=None, height=dp(38))
                done.bind(on_release=lambda _, g=game: self.mark_done(g))
                card.add_widget(done)
                for cat in CATEGORIES:
                    row = BoxLayout(size_hint_y=None, height=dp(38), spacing=dp(3))
                    row.add_widget(Label(text=cat, size_hint_x=.42, halign="left"))
                    current = game.get("ratings", {}).get(cat, 0)
                    for n in range(1, 6):
                        b = Button(text=("★" if n <= current else "☆"), font_size="18sp")
                        b.bind(on_release=lambda _, g=game, c=cat, v=n: self.rate(g,c,v))
                        row.add_widget(b)
                    card.add_widget(row)
                vals = list(game.get("ratings", {}).values())
                avg = sum(vals)/len(vals) if vals else 0
                card.add_widget(Label(text=f"Průměrné hodnocení: {avg:.1f}/5", size_hint_y=None, height=dp(26)))
                delete = Button(text="SMAZAT HRU", size_hint_y=None, height=dp(36),
                                background_normal="", background_color=(.42,.12,.16,1))
                delete.bind(on_release=lambda _, g=game: self.confirm_delete(g))
                card.add_widget(delete)
            with card.canvas.before:
                from kivy.graphics import Color, RoundedRectangle
                Color(0.075, 0.09, 0.13, 1)
                card.bg = RoundedRectangle(pos=card.pos, size=card.size, radius=[dp(10)])
            card.bind(pos=lambda inst, val: setattr(inst.bg, "pos", val),
                      size=lambda inst, val: setattr(inst.bg, "size", val))
            container.add_widget(card)

    def toggle(self, game):
        game["expanded"] = not game.get("expanded", True)
        self.refresh()

    def mark_done(self, game):
        game["done"] = not game.get("done", False)
        self.save_data()
        self.refresh()

    def confirm_delete(self, game):
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        box.add_widget(Label(text=f"Opravdu smazat {game['name']}?"))
        row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        popup = Popup(title="Potvrdit smazání", content=box, size_hint=(.85,None), height=dp(160))
        no = Button(text="Zrušit"); yes = Button(text="Smazat")
        row.add_widget(no); row.add_widget(yes); box.add_widget(row)
        no.bind(on_release=popup.dismiss)
        def remove(_):
            self.games.remove(game); self.save_data(); self.refresh(); popup.dismiss()
        yes.bind(on_release=remove)
        popup.open()

if __name__ == "__main__":
    GrannyTracker().run()
